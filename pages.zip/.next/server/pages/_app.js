(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 4498:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ App)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/Layout/Footer.tsx


const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "footer-section",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "custom-container",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "pb-8 md:pb-0",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "pb-4",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            className: "w-48 mx-auto lg:mx-0 lg:mr-auto",
                                            src: "/images/dorado-logo-2.png",
                                            alt: "image"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "text-center lg:text-start",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "fa-brands fa-square-instagram green-text hover:text-white text-4xl pr-4"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "fa-brands fa-youtube green-text hover:text-white text-4xl pr-4"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "fa-brands fa-square-facebook green-text hover:text-white text-4xl pr-4"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "fa-brands fa-linkedin green-text hover:text-white text-4xl"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "text-center lg:text-start",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                    className: "text-lg text-white font-EvilEmpire pb-8",
                                    children: "COMPANY"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "pb-8",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: "text text-white hover:text-[#27e124]",
                                        href: "/#welcome-section",
                                        children: "About"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "pb-8",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: "text text-white hover:text-[#27e124]",
                                        href: "/#road-map-section",
                                        children: "Roadmap"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "pb-8",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: "text text-white hover:text-[#27e124]",
                                        href: "/#white-paper-section",
                                        children: "Whitepaper"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "pb-8",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: "text text-white hover:text-[#27e124]",
                                        href: "/#token-economic-section",
                                        children: "Token Economy"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "text-center lg:text-start",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                    className: "text-lg text-white font-EvilEmpire pb-8",
                                    children: "Sales"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "pb-8",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: "text text-white hover:text-[#27e124]",
                                        href: "/#play-and-earn-section",
                                        children: "Play"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "pb-8",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: "text text-white hover:text-[#27e124]",
                                        href: "/#play-and-earn-section",
                                        children: "Earn"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "pb-8",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: "text text-white hover:text-[#27e124]",
                                        href: "/#count-down-section",
                                        children: "Scholarship"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "pb-8",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: "text text-white hover:text-[#27e124]",
                                        href: "/#wallet-section",
                                        children: "Wallet"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "text-center lg:text-start",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                    className: "text-lg text-white font-EvilEmpire pb-8",
                                    children: "NEWSLETTER"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                type: "text",
                                                className: "bg-transparent border border-gray-300 text-white text rounded-lg focus:ring-[#27e124] focus:border-[#27e124] block w-full px-2.5 py-4 placeholder-gray-300 mb-3",
                                                placeholder: "Enter your email address",
                                                required: true
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                type: "submit",
                                                className: "text-[#072626] bg-[#27e124] hover:bg-white focus:ring-4 focus:ring-[#28e4ab] rounded-lg text font-semibold px-5 mr-2 mb-2 focus:outline-none w-full py-4",
                                                children: "Subscribe Now"
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "border-t border-[#979797] mt-8 pt-8",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text text-white text-center",
                        children: "Copyright \xa9 Dorado All Rights Reserved"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const Layout_Footer = (Footer);

;// CONCATENATED MODULE: ./components/Layout/Layout.tsx


const Layout = ({ children  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            children,
            /*#__PURE__*/ jsx_runtime_.jsx(Layout_Footer, {})
        ]
    });
};
/* harmony default export */ const Layout_Layout = (Layout);

// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(6764);
;// CONCATENATED MODULE: ./pages/_app.tsx



function App({ Component , pageProps  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(Layout_Layout, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
            ...pageProps
        })
    });
}


/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [664], () => (__webpack_exec__(4498)));
module.exports = __webpack_exports__;

})();